# Low Poly Nature Pack (Free)
by reodesuxz

25 low poly nature props: trees, plants, flowers, mushrooms, rocks and logs.

## Contents
- FBX/  - one .fbx per model (Unity, Unreal, Godot, Blender)
- GLB/  - one .glb per model (Godot, three.js, Babylon.js, web)
- OBJ/  - one .obj + .mtl per model
- Nature_AllAssets.blend - every model in one Blender file (Blender 4.3+)

## Specs
- Total: 3824 triangles for all 25 models (20-456 tris each)
- Flat-shaded, simple shared materials (no textures needed)
- Real-world scale in metres, pivot at the base centre

| Model | Category | Tris | Size (cm) |
|---|---|---|---|
| pine_tree | Trees | 56 | 253 x 247 x 428 |
| pine_tall | Trees | 68 | 234 x 228 x 774 |
| round_tree | Trees | 64 | 238 x 194 x 361 |
| birch_tree | Trees | 132 | 222 x 189 x 493 |
| palm_tree | Trees | 438 | 362 x 371 x 421 |
| dead_tree | Trees | 84 | 121 x 85 x 245 |
| bush_round | Plants | 60 | 159 x 109 x 98 |
| bush_berries | Plants | 220 | 131 x 103 x 92 |
| fern | Plants | 280 | 180 x 184 x 16 |
| grass_tuft | Plants | 36 | 25 x 31 x 45 |
| flower_red | Plants | 304 | 26 x 20 x 33 |
| flower_yellow | Plants | 304 | 24 x 22 x 37 |
| flower_purple | Plants | 456 | 32 x 20 x 35 |
| cactus | Plants | 192 | 106 x 50 x 167 |
| mushroom_red | Plants | 272 | 40 x 38 x 33 |
| mushroom_cluster | Plants | 320 | 35 x 33 x 22 |
| lily_pad | Plants | 78 | 77 x 77 x 12 |
| cattails | Plants | 140 | 29 x 27 x 120 |
| rock_small | Rocks & Wood | 20 | 52 x 45 x 34 |
| rock_large | Rocks & Wood | 40 | 210 x 141 x 130 |
| rock_flat | Rocks & Wood | 20 | 147 x 106 x 29 |
| boulder_mossy | Rocks & Wood | 40 | 213 x 162 x 162 |
| rock_cluster | Rocks & Wood | 80 | 108 x 88 x 67 |
| tree_stump | Rocks & Wood | 56 | 108 x 96 x 55 |
| fallen_log | Rocks & Wood | 64 | 220 x 57 x 57 |

## License
See LICENSE.txt. Free to use in unlimited personal and commercial projects. You may not resell or redistribute the models themselves.
If this pack helped you, a small tip on itch.io keeps more free packs coming. Thank you!
