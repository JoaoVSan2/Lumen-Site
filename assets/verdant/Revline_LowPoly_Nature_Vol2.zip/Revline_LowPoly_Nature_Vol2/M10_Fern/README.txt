Roblox Studio: File > Import 3D (or Asset Manager > Import).
- M10_Fern.glb: the whole model as one mesh (texture embedded). parts/*.glb: each part separately with its own texture.
- M10_Fern.obj + M10_Fern.mtl + M10_Fern_atlas.png: same model as OBJ (keep the 3 files in one folder).
- M10_Fern.fbx: text (ASCII) FBX, texture file M10_Fern_atlas.png next to it. Not tested in Roblox Studio: if it does not import, use the GLB.
Check the triangle count in Studio: sources disagree on the per-mesh limit (10,000-20,000), so this tool aims below 10,000.
