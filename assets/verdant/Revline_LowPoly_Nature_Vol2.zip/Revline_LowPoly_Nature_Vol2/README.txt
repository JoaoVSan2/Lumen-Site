Low Poly Nature Pack Vol.2
==========================
30 low-poly 3D assets: spruce, snow fir, cherry blossom, baobab, bamboo, mushrooms, crops, crystals, cliffs, snow, campfire, pond and beach shells.

Each asset has its own folder with:
  <Name>.glb / .fbx / .obj(+.mtl)  full model with a small color atlas texture
  parts/                          the same model split into separate parts (GLB + FBX)
  materials.txt                   flat colors used
  README.txt                      per-asset notes

Notes (please read):
- Flat-shaded low-poly style, solid colors on a tiny atlas; no PBR textures, no rigging.
- Models are built around the origin and designed to rest on the ground plane.
- No collision meshes are included.
- Not tested inside Roblox Studio or Unity/Unreal specifically; they are standard GLB/FBX/OBJ files. If an import looks off, try the other format or rescale.
- License: CC0 (see LICENSE.txt).

Assets:
  - M01_Spruce
  - M02_FirSnow
  - M03_Cypress
  - M04_Poplar
  - M05_CherryBlossom
  - M06_AppleTree
  - M07_Baobab
  - M08_Acacia
  - M09_BambooClump
  - M10_Fern
  - M11_MushroomRed
  - M12_MushroomCluster
  - M13_Pumpkins
  - M14_Sunflowers
  - M15_Tulips
  - M16_Lavender
  - M17_MossyRock
  - M18_CrystalCluster
  - M19_CliffPillar
  - M20_SandstoneMesa
  - M21_Driftwood
  - M22_BerryBush
  - M23_CornStalks
  - M24_WheatPatch
  - M25_HayBale
  - M26_SnowPile
  - M27_CampfireStones
  - M28_PondSmall
  - M29_SteppingStones
  - M30_BeachShells