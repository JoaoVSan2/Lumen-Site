Roblox Studio: File > Import 3D (or Asset Manager > Import).
- M19_CliffPillar.glb: the whole model as one mesh (texture embedded). parts/*.glb: each part separately with its own texture.
- M19_CliffPillar.obj + M19_CliffPillar.mtl + M19_CliffPillar_atlas.png: same model as OBJ (keep the 3 files in one folder).
- M19_CliffPillar.fbx: text (ASCII) FBX, texture file M19_CliffPillar_atlas.png next to it. Not tested in Roblox Studio: if it does not import, use the GLB.
Check the triangle count in Studio: sources disagree on the per-mesh limit (10,000-20,000), so this tool aims below 10,000.
