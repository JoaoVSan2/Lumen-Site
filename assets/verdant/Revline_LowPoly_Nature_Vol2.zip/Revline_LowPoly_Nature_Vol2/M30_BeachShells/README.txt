Roblox Studio: File > Import 3D (or Asset Manager > Import).
- M30_BeachShells.glb: the whole model as one mesh (texture embedded). parts/*.glb: each part separately with its own texture.
- M30_BeachShells.obj + M30_BeachShells.mtl + M30_BeachShells_atlas.png: same model as OBJ (keep the 3 files in one folder).
- M30_BeachShells.fbx: text (ASCII) FBX, texture file M30_BeachShells_atlas.png next to it. Not tested in Roblox Studio: if it does not import, use the GLB.
Check the triangle count in Studio: sources disagree on the per-mesh limit (10,000-20,000), so this tool aims below 10,000.
