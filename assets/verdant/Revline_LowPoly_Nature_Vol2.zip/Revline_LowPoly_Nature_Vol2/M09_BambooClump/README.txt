Roblox Studio: File > Import 3D (or Asset Manager > Import).
- M09_BambooClump.glb: the whole model as one mesh (texture embedded). parts/*.glb: each part separately with its own texture.
- M09_BambooClump.obj + M09_BambooClump.mtl + M09_BambooClump_atlas.png: same model as OBJ (keep the 3 files in one folder).
- M09_BambooClump.fbx: text (ASCII) FBX, texture file M09_BambooClump_atlas.png next to it. Not tested in Roblox Studio: if it does not import, use the GLB.
Check the triangle count in Studio: sources disagree on the per-mesh limit (10,000-20,000), so this tool aims below 10,000.
