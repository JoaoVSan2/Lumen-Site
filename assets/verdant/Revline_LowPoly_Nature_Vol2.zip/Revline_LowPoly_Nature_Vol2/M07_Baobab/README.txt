Roblox Studio: File > Import 3D (or Asset Manager > Import).
- M07_Baobab.glb: the whole model as one mesh (texture embedded). parts/*.glb: each part separately with its own texture.
- M07_Baobab.obj + M07_Baobab.mtl + M07_Baobab_atlas.png: same model as OBJ (keep the 3 files in one folder).
- M07_Baobab.fbx: text (ASCII) FBX, texture file M07_Baobab_atlas.png next to it. Not tested in Roblox Studio: if it does not import, use the GLB.
Check the triangle count in Studio: sources disagree on the per-mesh limit (10,000-20,000), so this tool aims below 10,000.
