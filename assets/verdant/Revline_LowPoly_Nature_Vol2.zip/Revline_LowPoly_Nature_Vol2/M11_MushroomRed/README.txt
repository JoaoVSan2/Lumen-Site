Roblox Studio: File > Import 3D (or Asset Manager > Import).
- M11_MushroomRed.glb: the whole model as one mesh (texture embedded). parts/*.glb: each part separately with its own texture.
- M11_MushroomRed.obj + M11_MushroomRed.mtl + M11_MushroomRed_atlas.png: same model as OBJ (keep the 3 files in one folder).
- M11_MushroomRed.fbx: text (ASCII) FBX, texture file M11_MushroomRed_atlas.png next to it. Not tested in Roblox Studio: if it does not import, use the GLB.
Check the triangle count in Studio: sources disagree on the per-mesh limit (10,000-20,000), so this tool aims below 10,000.
