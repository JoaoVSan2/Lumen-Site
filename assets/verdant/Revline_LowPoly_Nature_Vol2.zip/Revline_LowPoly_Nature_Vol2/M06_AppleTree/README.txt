Roblox Studio: File > Import 3D (or Asset Manager > Import).
- M06_AppleTree.glb: the whole model as one mesh (texture embedded). parts/*.glb: each part separately with its own texture.
- M06_AppleTree.obj + M06_AppleTree.mtl + M06_AppleTree_atlas.png: same model as OBJ (keep the 3 files in one folder).
- M06_AppleTree.fbx: text (ASCII) FBX, texture file M06_AppleTree_atlas.png next to it. Not tested in Roblox Studio: if it does not import, use the GLB.
Check the triangle count in Studio: sources disagree on the per-mesh limit (10,000-20,000), so this tool aims below 10,000.
