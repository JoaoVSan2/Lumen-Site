# Low Poly Carnival Pack (Free)
by reodesuxz

27 low poly models for a haunted night fairground: tents, rides, game stalls, spooky props.

## Contents
- FBX/  - one .fbx per model (Unity, Unreal, Godot, Blender)
- GLB/  - one .glb per model (Godot, three.js, Babylon.js, web)
- OBJ/  - one .obj + .mtl per model
- Carnival_AllAssets.blend - every model in one Blender file (Blender 4.3+)

## Specs
- Total: 5180 triangles for all 27 models (56-448 tris each)
- Flat-shaded, simple shared materials (no textures needed)
- Real-world scale in metres, pivot at the base centre

| Model | Category | Tris | Size (cm) |
|---|---|---|---|
| big_top_tent | Tents & Buildings | 182 | 660 x 660 x 520 |
| ticket_booth | Tents & Buildings | 56 | 180 x 188 x 270 |
| fortune_teller_tent | Tents & Buildings | 108 | 300 x 300 x 360 |
| haunted_house | Tents & Buildings | 86 | 427 x 440 x 560 |
| mirror_maze_front | Tents & Buildings | 96 | 500 x 111 x 350 |
| ferris_wheel | Rides | 436 | 710 x 90 x 828 |
| carousel | Rides | 398 | 480 x 480 x 373 |
| bumper_car | Rides | 88 | 140 x 100 x 153 |
| swing_chair_ride | Rides | 214 | 440 x 440 x 435 |
| roller_coaster_piece | Rides | 216 | 500 x 100 x 205 |
| popcorn_cart | Stalls | 244 | 157 x 133 x 225 |
| cotton_candy_stand | Stalls | 168 | 146 x 170 x 280 |
| ring_toss_stall | Stalls | 448 | 220 x 125 x 230 |
| strength_tester | Stalls | 220 | 149 x 50 x 360 |
| duck_shooting_gallery | Stalls | 164 | 260 x 125 x 253 |
| ghost | Spooky | 152 | 100 x 100 x 135 |
| evil_clown_statue | Spooky | 234 | 118 x 80 x 225 |
| tombstone | Spooky | 88 | 90 x 30 x 145 |
| dead_tree | Spooky | 68 | 186 x 70 x 265 |
| skull_pumpkin_lantern | Spooky | 56 | 89 x 88 x 88 |
| iron_fence | Spooky | 186 | 240 x 10 x 108 |
| string_lights_pole | Props | 184 | 253 x 16 x 304 |
| balloon_bunch | Props | 180 | 99 x 99 x 251 |
| circus_cannon | Props | 156 | 102 x 144 x 156 |
| clown_juggling_pins | Props | 360 | 64 x 18 x 76 |
| carnival_sign_arch | Props | 288 | 380 x 43 x 405 |
| trash_bin_and_bench | Props | 104 | 220 x 60 x 100 |

## License
See LICENSE.txt. Free to use in unlimited personal and commercial projects. You may not resell or redistribute the models themselves.
If this pack helped you, a small tip on itch.io keeps more free packs coming. Thank you!
