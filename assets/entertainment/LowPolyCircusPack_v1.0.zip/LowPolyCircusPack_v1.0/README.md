# Low Poly Circus Pack (Free)
by reodesuxz

27 low poly circus and carnival assets: tents, booths, rides and performer props.

## Contents
- FBX/  - one .fbx per model (Unity, Unreal, Godot, Blender)
- GLB/  - one .glb per model (Godot, three.js, Babylon.js, web)
- OBJ/  - one .obj + .mtl per model
- Circus_AllAssets.blend - every model in one Blender file (Blender 4.3+)

## Specs
- Total: 4686 triangles for all 27 models (36-588 tris each)
- Flat-shaded, simple shared materials (no textures needed)
- Real-world scale in metres, pivot at the base centre

| Model | Category | Tris | Size (cm) |
|---|---|---|---|
| big_top | Tents | 230 | 860 x 860 x 660 |
| small_tent | Tents | 36 | 269 x 269 x 230 |
| ticket_booth | Tents | 56 | 160 x 195 x 280 |
| fortune_tent | Tents | 78 | 310 x 310 x 260 |
| game_booth | Booths | 144 | 280 x 148 x 270 |
| popcorn_cart | Booths | 252 | 140 x 106 x 233 |
| cotton_candy_stand | Booths | 168 | 105 x 110 x 148 |
| lemonade_stand | Booths | 88 | 170 x 104 x 210 |
| carousel | Rides | 424 | 480 x 480 x 365 |
| ferris_wheel | Rides | 588 | 860 x 692 x 1431 |
| bumper_car | Rides | 96 | 143 x 180 x 224 |
| swing_ride | Rides | 252 | 448 x 400 x 417 |
| helter_slide | Rides | 72 | 120 x 371 x 240 |
| cannon | Props | 156 | 112 x 194 x 172 |
| balloon_bunch | Props | 92 | 143 x 100 x 292 |
| circus_ball | Props | 168 | 122 x 122 x 120 |
| podium | Props | 176 | 164 x 164 x 94 |
| hoop_stand | Props | 168 | 108 x 105 x 214 |
| juggling_pins | Props | 360 | 74 x 14 x 50 |
| stilts | Props | 48 | 70 x 30 x 180 |
| clown_figure | Props | 166 | 67 x 52 x 190 |
| ticket_sign | Props | 48 | 140 x 17 x 240 |
| lion_cage | Props | 376 | 220 x 140 x 198 |
| trapeze | Props | 100 | 310 x 10 x 410 |
| stage_stool | Props | 88 | 72 x 72 x 52 |
| tightrope | Props | 60 | 450 x 50 x 260 |
| string_lights | Props | 196 | 410 x 12 x 202 |

## License
See LICENSE.txt. Free to use in unlimited personal and commercial projects. You may not resell or redistribute the models themselves.
If this pack helped you, a small tip on itch.io keeps more free packs coming. Thank you!
