PARTY PARK SAMPLER (FREE)  v1.0
13 stylised 3D models and 6 icons taken from my paid packs, so you can try the style and quality for free.

MODELS (GLB, textures embedded; open in Godot, Blender, three.js, Unity with glTFast, Unreal with the glTF importer)
- Inflatable Obstacle Course Kit HD: Bounce Dome, Cone Marker
- Carnival Games & Snack Stands Kit HD: Popcorn Cart, Balloon Bunch
- Mini Golf Course Kit HD: Straight Tile, Hole Tile
- Kids Birthday Party Kit HD: Cupcake
- Water Park & Pool Kit HD: Duck Float
- Playground & City Park Kit HD: Spring Rider (Horse), Park Bench
- Stylized Nature Kit HD: Oak Tree, Medium Rock, Flower Patch
ICONS (PNG 256 px, transparent) from 3D Game Icons - Rewards & Items: coin, gem, heart, star, potion, chest

The full packs add 3 LODs, collision, tested Unity 6 (URP) packages, Unreal FBX, Blender sources and many more assets:
https://adielfru.itch.io

LICENSE
Free for personal and commercial projects. Modify freely. Do not resell or redistribute the files themselves.
Credit appreciated (AdielFru), not required.
Made with AI assistance: models were built procedurally in code in Blender and checked in Blender, Unity and Unreal.
