# Amusement Park Pack - 300 3D Rides & Attractions

300 stylized amusement park models in two sets: 200 small rides and park
facilities, and 100 large attractions. Every model ships as GLB in three levels
of detail (LOD0, LOD1, LOD2), as an editable Blender source and as a preview image.

## What's inside

**`Amusement_Park/`: 200 small rides & park facilities (0001-0200)**

- 0001-0040 (Batch_01): coin-operated kiddie rides and mini rides
- 0041-0080 (Batch_02): claw machines, arcade cabinets, table games and redemption games
- 0081-0120 (Batch_03): carnival games, ticket and token machines, gates, queue barriers and guest service counters
- 0121-0160 (Batch_04): wayfinding, entry arches, scan and rental kiosks, benches, prize displays, capsule and vending machines, food carts and souvenir stands
- 0161-0200 (Batch_05): prize bins and counters, a locker wall, mini train and track pieces, ride vehicles and boats, carnival game booths and photo spots

**`Large_Amusement_Attractions/`: 100 large attractions (0001-0100)**

- 0001-0040 (Batch_01): roller coasters, Ferris and observation wheels, towers, swing and thrill rides
- 0041-0080 (Batch_02): flat rides, water rides, dark rides, walkthroughs, theaters and simulators
- 0081-0100 (Batch_03): sky rides, monorails and railway, adventure towers, slides and water play

## Numbering

Each set numbers its models from 0001. `Amusement_Park/.../0001_Coin_Operated_Horse_Ride` and
`Large_Amusement_Attractions/.../0001_Steel_Sit_Down_Roller_Coaster` are different models, so always
refer to a model by its set folder and number. `Catalog.csv` has a `group` column
for this.

## Folder layout

```
AmusementPark/
  README.md  LICENSE.txt  Catalog.csv
  Amusement_Park/                 200 small rides & park facilities
    Catalog.json
    Batch_01/ ... Batch_05/
      Blender/NNNN_Name.blend
      Models/NNNN_Name_LOD0.glb  NNNN_Name_LOD1.glb  NNNN_Name_LOD2.glb
      Preview_Images/NNNN_Name.png
      Batch_NN_40_Models_20_Seconds.gif
  Large_Amusement_Attractions/    100 large attractions
    Catalog.json
    Batch_01/ ... Batch_03/       (same layout)
```

The itch.io downloads are split into five zips. They all extract into the same
`AmusementPark/` folder, so you can unzip any combination on top of each other:

- `AmusementPark_FREE_15.zip`: free sample: 15 models with LOD0/LOD1/LOD2 GLB, .blend and preview
- `AmusementPark_GLB_LOD0_300.zip`: LOD0 GLB of all 300 models
- `AmusementPark_GLB_LOD1-LOD2_300.zip`: LOD1 and LOD2 GLB of all 300 models
- `AmusementPark_Blender_Source_300.zip`: .blend source of all 300 models
- `AmusementPark_Previews_GIFs_Docs.zip`: all preview PNGs, all batch GIFs and each set's Catalog.json

Every zip also contains `README.md`, `LICENSE.txt` and `Catalog.csv`.

## File formats

- `.glb` (glTF 2.0 binary): LOD0 is the full model. LOD1 and LOD2 simplify small
  details; capsule seam rings and selected small mounting details are removed in LOD2.
  900 GLB files.
- `.blend`: the editable LOD0 source, with named separate parts and the assembly
  hierarchy described below. Each scene also holds the preview camera, three area
  lights and a studio ground plane that is not part of the model. 300 files.
  **Saved with Blender 5.2: open with Blender 5.2 or newer.** Older Blender versions
  can import the `.glb` files instead (File > Import > glTF 2.0).
- `.png`: 512 x 512 preview of each model, rendered from its LOD0 GLB. 300 files.
- `.gif`: one animated overview per batch, 20 seconds, one frame per model.
  8 files (5 small, 3 large; the last large batch has 20 models, so its GIF is `Batch_03_20_Models_20_Seconds.gif`).
- `Catalog.csv`: one row per model with set, id, name, batch, free sample flag,
  triangles per LOD, material count and file paths (relative to `AmusementPark/`).
  `Catalog.json` in each set folder lists that set's files.

## Triangle counts (per model)

**Amusement_Park** (200 models)

| LOD | Average | Median | Min | Max |
|---|---|---|---|---|
| LOD0 | 5,276 | 4,766 | 304 | 16,570 |
| LOD1 | 3,140 | 2,800 | 192 | 10,286 |
| LOD2 | 1,737 | 1,555 | 100 | 5,600 |

**Large_Amusement_Attractions** (100 models)

| LOD | Average | Median | Min | Max |
|---|---|---|---|---|
| LOD0 | 13,682 | 9,705 | 2,176 | 35,476 |
| LOD1 | 7,920 | 5,321 | 1,378 | 24,558 |
| LOD2 | 5,027 | 3,330 | 732 | 17,536 |

## Hierarchy and pivots

Every model, in both the `.blend` and the GLB files, is organised under an
`Asset_Root` empty with two children: `Fixed_Structure` and `Moving_Assemblies`.
Moving parts are grouped under controller empties inside `Moving_Assemblies`.

Pivots were reviewed on these assemblies:

- Small #0021 Mini Carousel: `Carousel_Rotor` with `Horse_NN` children.
- Small #0107 Swing Barrier Gate: `Barrier_Hinge` (#0108 Wide Accessible Gate has
  the same `Barrier_Hinge` control).
- Small #0165 Locker Wall Unit: `Locker_Door_01` to `Locker_Door_20`.
- Large #0017 Ferris Wheel: `Wheel_Axle` with `Gondola_01` to `Gondola_16` (gondolas
  need counter-rotation to stay level).
- Large #0028 Giant Frisbee: `Swing_Axle` and `Gondola_Spin`.
- Large #0090 Observation Monorail Loop: `Monorail_Orbit`.

In the `.blend` files these reviewed controllers carry a `rotation_axis` custom
property (and the Ferris wheel gondolas a `counter_rotation_required` flag); GLB
files do not store these custom properties.

Other controllers (for example `Primary_Motion`, `Vehicle_NN`, `Motion_...`) are
placed at assembly centres as organisation aids and may need their pivots adjusted
for your own animation. No ride animations, constraints, rigs, colliders or physics
are included.

## Materials

- Flat PBR colours (metallic/roughness factors). No image textures.
- Closed meshes use one-sided materials; transparent and open meshes are double-sided.
- Transparent panels (32 small and 18 large models) use alpha blending (base colour alpha 0.3)
  together with `KHR_materials_transmission`, `KHR_materials_ior` and
  `KHR_materials_clearcoat`. Importers that ignore these extensions still show the
  panels as alpha-blended.
- In the GLBs, static geometry is merged by material and spatial sector to keep the
  mesh count low; the `.blend` files keep every named part separate.

## Engines

- Unity: import the GLB with glTFast or UnityGLTF. Place the LOD0, LOD1 and LOD2
  objects under one parent and assign their renderers to a LODGroup.
- Unreal Engine 5: import the GLB with the Interchange glTF importer. Keep the node
  hierarchy if you want to animate the moving assemblies; for static props you can
  combine the meshes and add LOD1/LOD2 as LODs in the Static Mesh Editor.
- Godot 4: drag the GLB into the project; it imports as a scene with the same
  hierarchy. Use GeometryInstance3D visibility ranges to switch between LODs.
- Blender: open the `.blend` (5.2+), or File > Import > glTF 2.0 for the GLB.

Triangle counts are not FPS measurements; profile performance in your target engine.

## Free sample

The free download contains 15 models with all their files: small
0001-0010 and large 0001-0005.

## License

Royalty-free for personal and commercial projects. No reselling or redistributing the
files, original or modified. See `LICENSE.txt`.

Made with Claude + Blender by Surprise Development (S_D).
https://surprise-development.itch.io  |  yling210047@gmail.com
